from .basic_commands import fprint
from .basic_commands import enter_to_continue
from .basic_commands import better_input